import urllib
import hashlib
import datetime

from collections import OrderedDict

from django.shortcuts import render
from django.conf import settings
from django.http import HttpResponse
from django.views.generic import TemplateView, View
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt


# 檢查碼演算法
def createCheckValue(data):
    data = OrderedDict(data)
    data = OrderedDict(sorted(data.items()))

    orderedDict = OrderedDict()
    orderedDict['HashKey'] = settings.ECPAY_API_HASH_KEY
    for field in data:
        orderedDict[field] = data[field]
    orderedDict['HashIV'] = settings.ECPAY_API_HASH_IV

    dataList = []
    for k, v in orderedDict.items():
        dataList.append("%s=%s" % (k, v))
    dataStr = u"&".join(dataList)
    
    
    encodeStr = urllib.parse.urlencode({'data': dataStr,})[5:]
    checkValue = hashlib.md5(encodeStr.lower().encode()).hexdigest().upper()
    
    return checkValue

class PaymentFormView(TemplateView):

    template_name = 'main/payment.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # 參考 5. 產生訂單
        payment_data = {
            # === 必填欄位 ===
            # 付款資訊
            "MerchantID": settings.ECPAY_MERCHEAT_ID,
            "ReturnURL": "http://127.0.0.1:8000/payment/backend/return/", # 我沒用這個，但因為是必填，所以先設計個 view 接它。
            "ChoosePayment": "ALL",
            "PaymentType": "aio",
            
            # 訂單資訊
            "MerchantTradeNo": hashlib.md5(str(datetime.datetime.now()).encode()).hexdigest()[0:20], # 訂單號
            "MerchantTradeDate": datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S"), # 訂單建立日期
            
            # 商品資訊
            "TotalAmount": "80",
            "TradeDesc": "ecpay 商城購物",
            "ItemName": "手機 20 元 X2#隨身碟60 元 X1",

            
            # === 選填欄位 ===
            "OrderResultURL": "http://127.0.0.1:8000/payment/frontend/return/", # 主要用這個 view 接結果
        }
        
        # 檢查碼機制，參考 15.檢查碼機制
        payment_data["CheckMacValue"] = createCheckValue(payment_data)
        
        context.update({
            "ECPAY_API_URL": settings.ECPAY_API_URL,
            "formData": payment_data,
        })
        
        return context

@method_decorator(csrf_exempt, name='dispatch')        
class PaymentReturnView(View):

    def post(self, request, *args, **kwargs):
        
        # request.POST 就是付款結果
        print(request.POST)
        
        # 根據付款結果做後續處理，EX: 設定訂單為已付款、付款失敗時的處理...等等
        
        return HttpResponse(str(request.POST.dict()))
